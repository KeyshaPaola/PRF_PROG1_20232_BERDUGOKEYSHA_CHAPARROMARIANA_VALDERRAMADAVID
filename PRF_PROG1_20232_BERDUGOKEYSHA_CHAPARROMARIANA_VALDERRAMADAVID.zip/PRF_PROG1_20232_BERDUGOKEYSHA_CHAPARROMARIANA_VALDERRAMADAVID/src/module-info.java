/**
 * 
 */
/**
 * @author Jeronimo
 *
 */
module PRF_PROG1_20232_BERDUGOKEYSHA_CHAPARROMARIANA_VALDERRAMADAVID {
	requires java.desktop;
}