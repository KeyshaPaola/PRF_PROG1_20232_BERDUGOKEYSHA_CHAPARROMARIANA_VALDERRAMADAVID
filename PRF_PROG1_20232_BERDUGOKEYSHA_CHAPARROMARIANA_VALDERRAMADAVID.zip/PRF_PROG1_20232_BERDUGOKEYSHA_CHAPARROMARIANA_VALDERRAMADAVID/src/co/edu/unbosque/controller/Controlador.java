package co.edu.unbosque.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.JTextField;

import co.edu.unbosque.model.Apostador;
import co.edu.unbosque.model.Baloto;
import co.edu.unbosque.model.BetPlay;
import co.edu.unbosque.model.Chance;
import co.edu.unbosque.model.GestionApostadores;
import co.edu.unbosque.model.Juego;
import co.edu.unbosque.model.Loteria;
import co.edu.unbosque.model.Partido;
import co.edu.unbosque.model.Superastro;
import co.edu.unbosque.model.persistence.AchivoApostadores;
import co.edu.unbosque.model.persistence.ApuestasArchivoPlano;
import co.edu.unbosque.model.persistence.CasaApuestasDAO;
import co.edu.unbosque.model.persistence.JuegoArchivoPlano;
import co.edu.unbosque.view.VentanaBaloto;
import co.edu.unbosque.view.VentanaBetPlay;
import co.edu.unbosque.view.VentanaChance;
import co.edu.unbosque.view.VentanaEmergente;
import co.edu.unbosque.view.VentanaLoteria;
import co.edu.unbosque.view.VentanaPrincipal;
import co.edu.unbosque.view.VentanaRegistroApostador;
import co.edu.unbosque.view.VentanaSuperastro;

public class Controlador {
	private VentanaPrincipal vista;
	private ActionListener listener;
	private VentanaBaloto baloto;
	private VentanaChance chance;
	private VentanaLoteria lote;
	private VentanaBetPlay ventanabet;
	private VentanaSuperastro sup;
	private static VentanaEmergente eme;
	private Loteria loteria;
	private Superastro superastro;
	private static Baloto balotoModel;
	private BetPlay betPlay;
	private CasaApuestasDAO casaApuestasDAO;
	private JuegoArchivoPlano juegoArchivoPlano;
	private ArrayList<Juego> juegos;
	private GestionApostadores gestionApostadores;
	private VentanaRegistroApostador registroApostador;
	private Chance chanceModel;
	 private ArrayList<Apostador> listaApostadores;

	public Controlador() {
		listener = new ListenerUsuario();
		vista = new VentanaPrincipal(listener);
		baloto = new VentanaBaloto(listener);
		chance = new VentanaChance(listener, this);
		lote = new VentanaLoteria(listener);
		ventanabet = new VentanaBetPlay(listener, this);
		sup = new VentanaSuperastro(listener);
		eme = new VentanaEmergente();
		loteria = new Loteria(null, null, 0);
		superastro = new Superastro(null, null, 0);
		balotoModel = new Baloto(null, null, 0);
		betPlay = new BetPlay(null, null, 0);
		casaApuestasDAO = new ApuestasArchivoPlano();
		juegoArchivoPlano = new JuegoArchivoPlano();
		juegos = new ArrayList<>();
        List<Juego> juegosLeidos = juegoArchivoPlano.leerJuegos();
        if (juegosLeidos != null) {
            juegos.addAll(juegosLeidos);
        }
		gestionApostadores = new GestionApostadores();
		registroApostador = new VentanaRegistroApostador(listener);
		chanceModel = new Chance(null, null, 0);
		listaApostadores = new ArrayList<>();
	}

	class ListenerUsuario implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			String comando = e.getActionCommand();

			switch (comando) {
			case "Loteria":
				lote.setVisible(true);
				break;
			case "Chance":
				chance.setVisible(true);
				break;
			case "Baloto":
				baloto.setVisible(true);
				break;
			case "Betplay":
				ventanabet.setVisible(true);
				break;
			case "Superastro":
				sup.setVisible(true);
				break;
			case "Jugar":
				jugarLoteria();
				break;
			case "Salir":
				lote.dispose();
				break;
			case "JugarSuper":
				jugarSuperastro();
				break;
			case "SalirSuper":
				sup.dispose();
				break;
			case "SalirBaloto":
				baloto.dispose();
				break;
			case "SalirBetPlay":
				ventanabet.dispose();
				break;
			case "Registrar":
				registroApostador.setVisible(true);
				break;
			case "SalirChance":
				chance.dispose();
				break;
			case "GuardarRegistro":
				agregarApostador(null);
				break;
			case "CancelarRegistro":
				registroApostador.dispose();
				break;
			}
		}
	}

	public void jugarLoteria() {
		try {
			String numero = lote.getNumeroField().getText();
			String serie = lote.getSerieField().getText();
			String loteriaSeleccionada = (String) lote.getOpciones().getSelectedItem();

			if (!numero.matches("\\d{1,3}(,\\d{1,3}){3}")) {
				eme.mostrarMensaje("Error: Ingresa 4 números separados por coma.");
				return;
			}
			if (serie.length() != 3) {
				eme.mostrarMensaje("Error: La serie debe tener 3 caracteres.");
				return;
			}

			int[] numerosIngresados = Arrays.stream(numero.split(",")).mapToInt(s -> {
				try {
					return Integer.parseInt(s.trim());
				} catch (NumberFormatException e) {
					throw new NumberFormatException("Error: Ingresa números válidos.");
				}
			}).toArray();

			int[] numerosSorteados = loteria.realizarSorteo();
			boolean esGanador = loteria.verificarGanador(numerosIngresados, numerosSorteados, serie, serie);

			if (esGanador) {
				String mensaje = "¡Felicidades! Has ganado en la lotería " + loteriaSeleccionada + "\n"
						+ "Números ingresados: " + Arrays.toString(numerosIngresados) + "\n" + "Números ganadores: "
						+ Arrays.toString(numerosSorteados) + "\n" + "Serie ingresada: " + serie;
				eme.mostrarMensaje(mensaje);
			} else {
				String mensaje = "Lo siento, no has ganado en la lotería " + loteriaSeleccionada + "\n"
						+ "Números ingresados: " + Arrays.toString(numerosIngresados) + "\n" + "Números ganadores: "
						+ Arrays.toString(numerosSorteados) + "\n" + "Serie ingresada: " + serie;
				eme.mostrarMensaje(mensaje);
			}
		} catch (NumberFormatException e) {
			eme.mostrarMensaje("Error: Ingresa números válidos.");
		}
	}

	public void jugarSuperastro() {
		try {
			String numerosStr = "";
			for (JTextField campoNumero : sup.getCamposNumeros()) {
				String texto = campoNumero.getText().trim();
				if (texto.length() != 1 || !texto.matches("[0-9]")) {
					eme.mostrarMensaje("Error: Ingresa un número entre 0 y 9 en cada campo.");
					return;
				}
				numerosStr += texto;
			}

			int[] numerosIngresados = Arrays.stream(numerosStr.split("")).mapToInt(Integer::parseInt).toArray();

			String signoSeleccionado = (String) sup.getOpciones().getSelectedItem();

			int[] numerosSorteados = superastro.generarNumerosAleatorios();

			String signoAleatorio = superastro.obtenerSignoZodiacalAleatorio();

			boolean esGanador = superastro.verificarGanador(numerosIngresados, signoSeleccionado);

			if (esGanador) {
				String mensaje = "¡Felicidades! Has ganado en Superastro.\n" + "Números ingresados: "
						+ Arrays.toString(numerosIngresados) + "\n" + "Signo zodiacal ingresado: " + signoSeleccionado
						+ "\n" + "Signo zodiacal aleatorio: " + signoAleatorio + "\n" + "Números sorteados: "
						+ Arrays.toString(numerosSorteados);
				eme.mostrarMensaje(mensaje);
			} else {
				String mensaje = "Lo siento, no has ganado en Superastro.\n" + "Números ingresados: "
						+ Arrays.toString(numerosIngresados) + "\n" + "Signo zodiacal ingresado: " + signoSeleccionado
						+ "\n" + "Signo zodiacal ganador: " + signoAleatorio + "\n" + "Números sorteados: "
						+ Arrays.toString(numerosSorteados);
				eme.mostrarMensaje(mensaje);
			}
		} catch (NumberFormatException e) {
			eme.mostrarMensaje("Error: Ingresa números válidos.");
		}
	}

	public static void procesarBaloto(int[] numeros) {
		try {
			for (int numero : numeros) {
				if (numero < 1 || numero > 45) {
					eme.mostrarMensaje("Error: Ingresa números entre 1 y 45.");
					return;
				}
			}

			int[] numerosSorteados = balotoModel.realizarSorteo();

			boolean esGanador = balotoModel.verificarGanador(numeros, numerosSorteados);

			if (esGanador) {
				String mensaje = "¡Felicidades! Has ganado en Baloto.\n" + "Números ingresados: "
						+ Arrays.toString(numeros) + "\n" + "Números ganadores: " + Arrays.toString(numerosSorteados);
				eme.mostrarMensaje(mensaje);
			} else {
				String mensaje = "Lo siento, no has ganado en Baloto.\n" + "Números ingresados: "
						+ Arrays.toString(numeros) + "\n" + "Números ganadores: " + Arrays.toString(numerosSorteados);
				eme.mostrarMensaje(mensaje);
			}
		} catch (NumberFormatException e) {
			eme.mostrarMensaje("Error: Ingresa números válidos.");
		}
	}

	public void procesarBetPlay(String[] equiposLocal, String[] equiposVisitante, int[] marcadoresLocal,
			int[] marcadoresVisitante) {
		try {
			if (validarEquipos(equiposLocal, "locales") && validarEquipos(equiposVisitante, "visitantes")
					&& validarMarcadores(marcadoresLocal, "locales")
					&& validarMarcadores(marcadoresVisitante, "visitantes")) {
				agregarPartidos(equiposLocal, equiposVisitante, marcadoresLocal, marcadoresVisitante);
				eme.mostrarMensaje("¡Juego BetPlay procesado correctamente!");
				ventanabet.setControlador(this);
			}
		} catch (NumberFormatException e) {
			eme.mostrarMensaje("Error: Ingresa números válidos en los marcadores.");
		}
	}

	private boolean validarEquipos(String[] equipos, String tipo) {
		for (String equipo : equipos) {
			if (equipo.isEmpty()) {
				eme.mostrarMensaje("Error: Debes ingresar todos los equipos " + tipo + ".");
				return false;
			}
		}
		return true;
	}

	private boolean validarMarcadores(int[] marcadores, String tipo) {
		for (int marcador : marcadores) {
			if (marcador < 0) {
				eme.mostrarMensaje("Error: Debes ingresar marcadores " + tipo + " válidos.");
				return false;
			}
		}
		return true;
	}

	private void agregarPartidos(String[] equiposLocal, String[] equiposVisitante, int[] marcadoresLocal,
			int[] marcadoresVisitante) {
		for (int i = 0; i < equiposLocal.length; i++) {
			Partido partido = new Partido(equiposLocal[i], equiposVisitante[i], marcadoresLocal[i],
					marcadoresVisitante[i]);
			betPlay.agregarPartido(partido);
		}
	}

	public void jugarChance(int[] numerosIngresados) {
		try {
			String numerosStr = "";
			for (JTextField campoNumero : chance.getCampoNumeros()) {
				String texto = campoNumero.getText().trim();
				if (texto.length() != 1 || !texto.matches("[0-9]")) {
					eme.mostrarMensaje("Error: Ingresa un número entre 0 y 9 en cada campo.");
					return;
				}
				numerosStr += texto;
			}
			String loteria = chanceModel.obtenerLoteria();
			int[] numerosSorteados = chanceModel.realizarSorteo();

			boolean esGanador = chanceModel.verificarGanador(numerosIngresados, numerosSorteados);

			if (esGanador) {
				String mensaje = "¡Felicidades! Has ganado en Chance.\n" + "Números ingresados: "
						+ Arrays.toString(numerosIngresados) + "\n" + "Números ganadores: "
						+ Arrays.toString(numerosSorteados) + "\n" + "Lotería: " + loteria;
				eme.mostrarMensaje(mensaje);
			} else {
				String mensaje = "Lo siento, no has ganado en Chance.\n" + "Números ingresados: "
						+ Arrays.toString(numerosIngresados) + "\n" + "Números ganadores: "
						+ Arrays.toString(numerosSorteados) + "\n" + "Lotería: " + loteria;
				eme.mostrarMensaje(mensaje);
			}
		} catch (NumberFormatException e) {
			eme.mostrarMensaje("Error: Ingresa números válidos.");
		}
	}

	public void configurarCasa(String nuevoNombre, int nuevoNumSedes, int nuevoPresupuesto) {
		casaApuestasDAO.configurarCasa(nuevoNombre, nuevoNumSedes, nuevoPresupuesto);
	}

	public void agregarJuego(Juego nuevoJuego) {
		juegos.add(nuevoJuego);
		juegoArchivoPlano.escribirJuegos(juegos);
	}

	public void modificarJuego(int indice, Juego juegoModificado) {
		juegos.set(indice, juegoModificado);
		juegoArchivoPlano.escribirJuegos(juegos);
	}

	public void eliminarJuego(int indice) {
		juegos.remove(indice);
		juegoArchivoPlano.escribirJuegos(juegos);
	}

	public void agregarApostador(Apostador apostador) {
		if (apostador == null) {
			try {
				String nombre = registroApostador.getCampoNombre().getText().trim();
				int cedula = Integer.parseInt(registroApostador.getCampoDocumento().getText().trim());
				int celular = Integer.parseInt(registroApostador.getCampoCelular().getText().trim());
				String direccion = registroApostador.getCampoDireccion().getText().trim();
				String sede = registroApostador.getCampoSede().getText().trim();

				int edad = Integer.parseInt(registroApostador.getCampoEdad().getText().trim());
				if (edad <= 18) {
					eme.mostrarMensaje("Error: La edad debe ser mayor a 18.");
					return;
				}

				apostador = new Apostador(nombre, cedula, celular, direccion, sede, edad);
			} catch (NumberFormatException e) {
				eme.mostrarMensaje("Error: Ingresa números válidos en los campos de Documento, Celular y Edad.");
				return;
			}
		}

		listaApostadores.add(apostador);
		registroApostador.dispose();

		eme.mostrarMensaje("Apostador agregado correctamente.");
	}

	public void realizarOperacionConApostadores() {
		Apostador nuevoApostador = new Apostador("Nombre", 123456789, 123, "Direccion", "Sede", 18);
		gestionApostadores.crearApostador(nuevoApostador);
	}

}
