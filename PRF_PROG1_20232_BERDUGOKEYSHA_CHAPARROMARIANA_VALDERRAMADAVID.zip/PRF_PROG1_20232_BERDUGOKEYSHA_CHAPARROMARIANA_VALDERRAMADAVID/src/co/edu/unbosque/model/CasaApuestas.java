package co.edu.unbosque.model;

import java.util.List;

public class CasaApuestas {
	private String nombre;
	private int numSedes;
	private int presupuesto;
	private int numEmpleado;
	private List<Juego> juegos;

	public CasaApuestas(String nombre, int numSedes, int presupuesto, int numEmpleado, List<Juego> juegos) {
		this.nombre = nombre;
		this.numSedes = numSedes;
		this.presupuesto = presupuesto;
		this.numEmpleado = numEmpleado;
		this.juegos = juegos;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getNumSedes() {
		return numSedes;
	}

	public void setNumSedes(int numSedes) {
		this.numSedes = numSedes;
	}

	public int getPresupuesto() {
		return presupuesto;
	}

	public void setPresupuesto(int presupuesto) {
		this.presupuesto = presupuesto;
	}

}
