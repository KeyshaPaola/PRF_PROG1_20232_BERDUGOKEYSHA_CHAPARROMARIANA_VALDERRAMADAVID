package co.edu.unbosque.model;

import java.util.List;

import co.edu.unbosque.model.persistence.AchivoApostadores;

public class GestionApostadores {
	private AchivoApostadores archivoApostadores;

	public GestionApostadores() {
		archivoApostadores = new AchivoApostadores();
	}

	public void crearApostador(Apostador apostador) {
		archivoApostadores.crearApostador(apostador);
	}

	public Apostador leerApostador(int cedula) {
		return archivoApostadores.leerApostador(cedula);
	}

	public List<Apostador> leerTodosLosApostadores() {
		return archivoApostadores.leerTodosLosApostadores();
	}

	public void actualizarApostador(Apostador apostadorActualizado) {
		archivoApostadores.actualizarApostador(apostadorActualizado);
	}

	public void borrarApostador(int cedula) {
		archivoApostadores.borrarApostador(cedula);
	}
}
