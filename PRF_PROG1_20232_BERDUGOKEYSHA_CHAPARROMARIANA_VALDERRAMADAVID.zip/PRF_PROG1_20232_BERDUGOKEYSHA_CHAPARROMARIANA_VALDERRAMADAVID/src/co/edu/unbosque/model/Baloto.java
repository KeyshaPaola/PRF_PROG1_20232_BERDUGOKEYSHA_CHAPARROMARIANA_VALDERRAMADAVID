package co.edu.unbosque.model;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Random;
import java.util.Set;
import java.util.stream.Collectors;

public class Baloto extends Juego implements Serializable{
	private static final int NUMEROS_A_ELEGIR = 6;
	private static final int RANGO_MINIMO = 1;
	private static final int RANGO_MAXIMO = 45;

	public Baloto(String nombre, String tipoDeJuego, int presupuesto) {
		super(nombre, tipoDeJuego, presupuesto);

	}

	public int[] realizarSorteo() {
		Random random = new Random();
		int[] numerosSorteados = new int[NUMEROS_A_ELEGIR];

		for (int i = 0; i < NUMEROS_A_ELEGIR; i++) {
			numerosSorteados[i] = random.nextInt(RANGO_MAXIMO - RANGO_MINIMO + 1) + RANGO_MINIMO;
		}

		Arrays.sort(numerosSorteados);

		return numerosSorteados;
	}

	public boolean verificarGanador(int[] numerosUsuario, int[] numerosSorteados) {
		Set<Integer> numerosUsuarioSet = Arrays.stream(numerosUsuario).boxed().collect(Collectors.toSet());
		Set<Integer> numerosSorteadosSet = Arrays.stream(numerosSorteados).boxed().collect(Collectors.toSet());

		return numerosUsuarioSet.equals(numerosSorteadosSet);

	}
}
