package co.edu.unbosque.model;

import java.io.Serializable;

public class Juego implements Serializable {
	protected String nombre;
	protected String tipoDeJuego;
	protected int presupuesto;

	public Juego(String nombre, String tipoDeJuego, int presupuesto) {

		this.nombre = nombre;
		this.tipoDeJuego = tipoDeJuego;
		this.presupuesto = presupuesto;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getTipoDeJuego() {
		return tipoDeJuego;
	}

	public void setTipoDeJuego(String tipoDeJuego) {
		this.tipoDeJuego = tipoDeJuego;
	}

	public int getPresupuesto() {
		return presupuesto;
	}

	public void setPresupuesto(int presupuesto) {
		this.presupuesto = presupuesto;
	}

	@Override
	public String toString() {
		return "Juego{" + "nombre='" + nombre + '\'' + ", tipoDeJuego='" + tipoDeJuego + '\'' + ", presupuesto="
				+ presupuesto + '}';
	}
}
