package co.edu.unbosque.model;

import java.io.Serializable;

public class Apostador implements Serializable{

	private String nombre;
	private int cedula;
	private int celular;
	private String direccion;
	private String sede;
	private int edad;

	public Apostador(String nombre, int cedula, int celular, String direccion, String sede,int edad) {
		this.nombre = nombre;
		this.cedula = cedula;
		this.celular = celular;
		this.direccion = direccion;
		this.sede = sede;
		this.edad = edad;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getCedula() {
		return cedula;
	}
	public void setCedula(int cedula) {
		this.cedula = cedula;
	}
	public int getCelular() {
		return celular;
	}
	public void setCelular(int celular) {
		this.celular = celular;
	}
	public String getDireccion() {
		return direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	public String getSede() {
		return sede;
	}
	public void setSede(String sede) {
		this.sede = sede;
	}
	
}


