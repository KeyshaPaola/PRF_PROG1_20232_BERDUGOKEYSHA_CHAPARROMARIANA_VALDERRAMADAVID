package co.edu.unbosque.model.persistence;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import co.edu.unbosque.model.Apostador;

public class AchivoApostadores implements ApostadorDAO {

	private static final String APOSTADORES_FILE = "Apostadores.dat";
	private List<Apostador> apostadores;

	public AchivoApostadores() {
		apostadores = new ArrayList<>();
		cargarApostadores();
	}

	private void cargarApostadores() {
		try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(APOSTADORES_FILE))) {
			Object obj = ois.readObject();
			if (obj instanceof List) {
				apostadores = (List<Apostador>) obj;
			}
		} catch (EOFException e) {
			//System.out.println("Fin del archivo alcanzado.");
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	private void guardarApostadores() {
		try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(APOSTADORES_FILE))) {
			oos.writeObject(apostadores);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void crearApostador(Apostador apostador) {
        apostadores.add(apostador);
        guardarApostadores();
        System.out.println("Apostador creado y guardado: " + apostador);
    }
	@Override
	public Apostador leerApostador(int cedula) {
		for (Apostador apostador : apostadores) {
			if (apostador.getCedula() == cedula) {
				return apostador;
			}
		}
		return null;
	}

	@Override
	public List<Apostador> leerTodosLosApostadores() {
		return new ArrayList<>(apostadores);
	}

	@Override
	public void actualizarApostador(Apostador apostadorActualizado) {
		for (Apostador apostador : apostadores) {
			if (apostador.getCedula() == apostadorActualizado.getCedula()) {
				apostador.setNombre(apostadorActualizado.getNombre());
				apostador.setSede(apostadorActualizado.getSede());
				apostador.setDireccion(apostadorActualizado.getDireccion());
				apostador.setCelular(apostadorActualizado.getCelular());
				guardarApostadores();
				System.out.println("Apostador actualizado y guardado: " + apostador);
				return;
			}
		}
	}

	@Override
	public void borrarApostador(int cedula) {
		apostadores.removeIf(apostador -> apostador.getCedula() == cedula);
		guardarApostadores();
		System.out.println("Apostador borrado y guardado.");
	}
}
