package co.edu.unbosque.model.persistence;

import java.util.ArrayList;
import java.util.List;

import co.edu.unbosque.model.Juego;

public interface JuegoDAO {
	public void escribirJuegos(List<Juego> juegos);

	public List<Juego> leerJuegos();

}
