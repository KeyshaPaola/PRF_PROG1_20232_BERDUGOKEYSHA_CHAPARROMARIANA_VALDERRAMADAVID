package co.edu.unbosque.model.persistence;

public interface CasaApuestasDAO {
	String obtenerNombreCasa();
    int obtenerNumSedes();
    int obtenerPresupuestoTotal();
    void configurarCasa(String nuevoNombre, int nuevoNumSedes, int nuevoPresupuesto);
}
