package co.edu.unbosque.model.persistence;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import co.edu.unbosque.model.Juego;

public class JuegoArchivoPlano implements JuegoDAO {
	private static final String JUEGOS_FILE = "Juegos.dat";

	public void escribirJuegos(List<Juego> juegos) {
		try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(JUEGOS_FILE))) {
			oos.writeObject(juegos);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public List<Juego> leerJuegos() {
		List<Juego> juegos = new ArrayList<>();
		try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(JUEGOS_FILE))) {
			Object obj = ois.readObject();
			if (obj instanceof List) {
				juegos = (List<Juego>) obj;
			}
		} catch (EOFException e) {
			//System.out.println("Fin del archivo alcanzado.");
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		return juegos;
	}
}
