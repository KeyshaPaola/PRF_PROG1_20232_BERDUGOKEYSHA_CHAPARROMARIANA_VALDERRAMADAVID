package co.edu.unbosque.model.persistence;

import java.util.List;

import co.edu.unbosque.model.Apostador;

public interface ApostadorDAO {
	void crearApostador(Apostador apostador);

	Apostador leerApostador(int cedula);

	List<Apostador> leerTodosLosApostadores();

	void actualizarApostador(Apostador apostador);

	void borrarApostador(int cedula);
}
