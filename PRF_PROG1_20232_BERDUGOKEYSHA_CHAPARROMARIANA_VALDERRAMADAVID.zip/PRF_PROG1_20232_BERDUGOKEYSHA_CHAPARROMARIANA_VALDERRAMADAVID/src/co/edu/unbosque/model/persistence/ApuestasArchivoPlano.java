package co.edu.unbosque.model.persistence;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class ApuestasArchivoPlano implements CasaApuestasDAO{
	private static final String CONFIG_FILE = "Config.properties";
	private Properties config;

	public ApuestasArchivoPlano() {
		config = new Properties();
		cargarConfig();
	}

	private void cargarConfig() {
		try (FileInputStream in = new FileInputStream(CONFIG_FILE)) {
			config.load(in);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void guardarConfig() {
		try (FileOutputStream outP = new FileOutputStream(CONFIG_FILE)) {
			config.store(outP, null);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public String obtenerNombreCasa() {
		return config.getProperty("nombre_casa");
	}

	@Override
	public int obtenerNumSedes() {
		return Integer.parseInt(config.getProperty("num_sedes"));
	}

	@Override
	public int obtenerPresupuestoTotal() {
		return Integer.parseInt(config.getProperty("presupuesto_total"));
	}

	@Override
	public void configurarCasa(String nuevoNombre, int nuevoNumSedes, int nuevoPresupuesto) {
		config.setProperty("nombre_casa", nuevoNombre);
		config.setProperty("num_sedes", String.valueOf(nuevoNumSedes));
		config.setProperty("presupuesto_total", String.valueOf(nuevoPresupuesto));
		guardarConfig();
	}

}
