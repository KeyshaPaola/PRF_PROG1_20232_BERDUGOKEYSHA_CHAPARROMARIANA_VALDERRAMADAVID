package co.edu.unbosque.model;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Random;

public class Loteria extends Juego implements Serializable{
	private static final int NUMEROS_A_ELEGIR = 4;
	private static final int DIGITOS_SERIE_MAXIMA = 3;

	public Loteria(String nombre, String tipoDeJuego, int presupuesto) {
		super(nombre, tipoDeJuego, presupuesto);

	}

	public static int getNumerosAElegir() {
		return NUMEROS_A_ELEGIR;
	}

	public static int getDigitosSerieMaxima() {
		return DIGITOS_SERIE_MAXIMA;
	}

	public int[] realizarSorteo() {
        Random random = new Random();
        int[] numerosSorteados = new int[NUMEROS_A_ELEGIR];

        for (int i = 0; i < NUMEROS_A_ELEGIR; i++) {
           
            numerosSorteados[i] = random.nextInt(10) + 1;
        }

        Arrays.sort(numerosSorteados); 

        return numerosSorteados;
    }
	
	public boolean verificarGanador(int[] numerosElegidos, int[] numerosSorteados, String serieJugador, String serieSorteada) {
	    
	    boolean numerosIguales = Arrays.equals(numerosElegidos, numerosSorteados);
	    boolean serieIgual = serieJugador.equals(serieSorteada);
	    return numerosIguales && serieIgual;

}}
