package co.edu.unbosque.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class Chance extends Juego implements Serializable {
	private static final int NUMEROS_A_ELEGIR = 4;
	private static final String[] LOTERIAS = { "Cundinamarca", "Boyacá", "Cauca" };

	public Chance(String nombre, String tipoDeJuego, int presupuesto) {
		super(nombre, tipoDeJuego, presupuesto);
	}

	public int[] realizarSorteo() {
		Random random = new Random();
		int[] numerosSorteados = new int[NUMEROS_A_ELEGIR];

		for (int i = 0; i < NUMEROS_A_ELEGIR; i++) {

			numerosSorteados[i] = random.nextInt(10) + 1;
		}

		Arrays.sort(numerosSorteados);

		return numerosSorteados;
	}

	public boolean verificarGanador(int[] numerosIngresados, int[] numerosSorteados) {
		Arrays.sort(numerosIngresados);
		return Arrays.equals(numerosIngresados, numerosSorteados);
	}

	public String obtenerLoteria() {
		Random random = new Random();
		int indiceAleatorio = random.nextInt(LOTERIAS.length);
		return LOTERIAS[indiceAleatorio];
	}
}
