package co.edu.unbosque.model;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Random;

public class Superastro extends Juego implements Serializable{
	private static final int CIFRAS_A_ELEGIR = 4;
	private static final String[] SIGNOS_ZODIACO = { "Aries", "Tauro", "Géminis", "Cáncer", "Leo", "Virgo", "Libra",
			"Escorpio", "Sagitario", "Capricornio", "Acuario", "Piscis" };

	private int[] numerosSeleccionados;
	private String signoZodiaco;

	public Superastro(String nombre, String tipoDeJuego, int presupuesto) {
		super(nombre, tipoDeJuego, presupuesto);
		this.numerosSeleccionados = new int[CIFRAS_A_ELEGIR];
		this.signoZodiaco = "";
	}
	
	public int[] generarNumerosAleatorios() {
        Random random = new Random();
        int[] numerosAleatorios = new int[CIFRAS_A_ELEGIR];

        for (int i = 0; i < CIFRAS_A_ELEGIR; i++) {
            numerosAleatorios[i] = random.nextInt(10); 
        }

        return numerosAleatorios;
    }
	public String obtenerSignoZodiacalAleatorio() {
        Random random = new Random();
        int indiceAleatorio = random.nextInt(SIGNOS_ZODIACO.length);
        return SIGNOS_ZODIACO[indiceAleatorio];
    }
	
	public boolean verificarGanador(int[] numerosIngresados, String signoIngresado) {
        boolean numerosIguales = Arrays.equals(numerosIngresados, numerosSeleccionados);
        boolean signoIgual = signoIngresado.equals(signoZodiaco);
        return numerosIguales && signoIgual;
    }


	public int[] getNumerosSeleccionados() {
		return numerosSeleccionados;
	}

	public void setNumerosSeleccionados(int[] numerosSeleccionados) {
		this.numerosSeleccionados = numerosSeleccionados;
	}

	public String getSignoZodiaco() {
		return signoZodiaco;
	}

	public void setSignoZodiaco(String signoZodiaco) {
		this.signoZodiaco = signoZodiaco;
	}

	public static int getCifrasAElegir() {
		return CIFRAS_A_ELEGIR;
	}

	public static String[] getSignosZodiaco() {
		return SIGNOS_ZODIACO;
	}

}
