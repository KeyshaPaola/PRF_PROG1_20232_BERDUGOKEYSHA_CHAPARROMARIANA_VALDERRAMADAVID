package co.edu.unbosque.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class BetPlay extends Juego implements Serializable{
	 private static final int PARTIDOS_A_ELEGIR = 14;
	    private List<Partido> partidosElegidos;
	    
	public BetPlay(String nombre, String tipoDeJuego, int presupuesto) {
		super(nombre, tipoDeJuego, presupuesto);
		this.partidosElegidos = new ArrayList<>();
		
	}
	public boolean limitePartidos() {
       return partidosElegidos.size() >= PARTIDOS_A_ELEGIR;
   }

   public void agregarPartido(Partido partido) {
       if (!limitePartidos()) {
           partidosElegidos.add(partido);
       } else {
           System.out.println("Error: Se ha alcanzado el límite de partidos a elegir.");
       }
   }
   public List<Partido> getPartidosElegidos() {
       return Collections.unmodifiableList(partidosElegidos);
   }

}
