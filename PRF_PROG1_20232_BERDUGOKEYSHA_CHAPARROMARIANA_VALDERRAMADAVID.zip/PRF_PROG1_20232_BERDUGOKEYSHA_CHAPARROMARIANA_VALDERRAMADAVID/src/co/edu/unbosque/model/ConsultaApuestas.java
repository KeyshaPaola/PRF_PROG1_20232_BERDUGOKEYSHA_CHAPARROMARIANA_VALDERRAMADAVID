package co.edu.unbosque.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ConsultaApuestas {

	 private Map<String, List<Apostador>> clientesPorSede;

    public ConsultaApuestas() {
        clientesPorSede = new HashMap<>();
    }

    public void agregarApostador(Apostador apostador) {
        clientesPorSede.computeIfAbsent(apostador.getSede(), k -> new ArrayList<>()).add(apostador);
    }

    public Map<String, List<Apostador>> obtenerClientesPorSede() {
        return clientesPorSede;
    }
}
