package co.edu.unbosque.view;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import co.edu.unbosque.controller.Controlador;

public class VentanaBetPlay extends JFrame {

	private JLabel[] etiquetasEquipos;
	private JTextField[] camposEquipoLocal;
	private JTextField[] camposEquipoVisitante;
	private JTextField[] camposMarcadorLocal;
	private JTextField[] camposMarcadorVisitante;
	private JButton jugar, salir;
	private ActionListener listener;
	private Controlador controlador;

	public VentanaBetPlay(ActionListener listener,Controlador controlador) {
		this.listener = listener;
		 this.controlador = controlador; 
		setSize(800, 500);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		getContentPane().setBackground(new Color(194, 225, 255));
		setLayout(new GridLayout(16, 4, 10, 10)); 
		setResizable(false);
		setLocationRelativeTo(null);
		inicializar();
		setVisible(false);
		setTitle("Betplay");
		pack();
	}

	private void inicializar() {
		etiquetasEquipos = new JLabel[14];
	    JLabel etiquetaEquipoLocal = new JLabel("Equipo Local");
	    JLabel etiquetaEquipoVisitante = new JLabel("Equipo Visitante");
	    JLabel etiquetaMarcadorLocal = new JLabel("Marcador Local");
	    JLabel etiquetaMarcadorVisitante = new JLabel("Marcador Visitante");
	    camposEquipoLocal = new JTextField[14];
	    camposEquipoVisitante = new JTextField[14];
	    camposMarcadorLocal = new JTextField[14];
	    camposMarcadorVisitante = new JTextField[14];

	    getContentPane().add(new JLabel());
	    getContentPane().add(etiquetaEquipoLocal);
	    getContentPane().add(etiquetaEquipoVisitante);
	    getContentPane().add(etiquetaMarcadorLocal);
	    getContentPane().add(etiquetaMarcadorVisitante);

	    for (int i = 0; i < 14; i++) {
	        etiquetasEquipos[i] = new JLabel("Partido " + (i + 1) + ":");
	        getContentPane().add(etiquetasEquipos[i]);

	        camposEquipoLocal[i] = new JTextField();
	        getContentPane().add(camposEquipoLocal[i]);

	        camposEquipoVisitante[i] = new JTextField();
	        getContentPane().add(camposEquipoVisitante[i]);

	        camposMarcadorLocal[i] = new JTextField();
	        getContentPane().add(camposMarcadorLocal[i]);

	        camposMarcadorVisitante[i] = new JTextField();
	        getContentPane().add(camposMarcadorVisitante[i]);
		}

		jugar = new JButton("Jugar");
		getContentPane().add(jugar);

		salir = new JButton("Salir");
		getContentPane().add(salir);
		salir.setActionCommand("SalirBetPlay");
		salir.addActionListener(listener);

		jugar.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String[] equiposLocal = new String[14];
				String[] equiposVisitante = new String[14];
				int[] marcadoresLocal = new int[14];
				int[] marcadoresVisitante = new int[14];

				for (int i = 0; i < 14; i++) {
					equiposLocal[i] = camposEquipoLocal[i].getText();
					equiposVisitante[i] = camposEquipoVisitante[i].getText();

					try {
						marcadoresLocal[i] = Integer.parseInt(camposMarcadorLocal[i].getText());
						marcadoresVisitante[i] = Integer.parseInt(camposMarcadorVisitante[i].getText());
					} catch (NumberFormatException ex) {
						System.out.println("Ingrese números válidos en todos los campos.");
						return;
					}
				}
				controlador.procesarBetPlay(equiposLocal, equiposVisitante, marcadoresLocal, marcadoresVisitante);

			}

		});
	}
	public void setControlador(Controlador controlador) {
        this.controlador = controlador;
    }

	public JLabel[] getEtiquetasEquipos() {
		return etiquetasEquipos;
	}

	public void setEtiquetasEquipos(JLabel[] etiquetasEquipos) {
		this.etiquetasEquipos = etiquetasEquipos;
	}

	public JTextField[] getCamposEquipoLocal() {
		return camposEquipoLocal;
	}

	public void setCamposEquipoLocal(JTextField[] camposEquipoLocal) {
		this.camposEquipoLocal = camposEquipoLocal;
	}

	public JTextField[] getCamposEquipoVisitante() {
		return camposEquipoVisitante;
	}

	public void setCamposEquipoVisitante(JTextField[] camposEquipoVisitante) {
		this.camposEquipoVisitante = camposEquipoVisitante;
	}

	public JTextField[] getCamposMarcadorLocal() {
		return camposMarcadorLocal;
	}

	public void setCamposMarcadorLocal(JTextField[] camposMarcadorLocal) {
		this.camposMarcadorLocal = camposMarcadorLocal;
	}

	public JTextField[] getCamposMarcadorVisitante() {
		return camposMarcadorVisitante;
	}

	public void setCamposMarcadorVisitante(JTextField[] camposMarcadorVisitante) {
		this.camposMarcadorVisitante = camposMarcadorVisitante;
	}

	public JButton getJugar() {
		return jugar;
	}

	public void setJugar(JButton jugar) {
		this.jugar = jugar;
	}

	public JButton getSalir() {
		return salir;
	}

	public void setSalir(JButton salir) {
		this.salir = salir;
	}

	public Controlador getControlador() {
		return controlador;
	}
	
}
