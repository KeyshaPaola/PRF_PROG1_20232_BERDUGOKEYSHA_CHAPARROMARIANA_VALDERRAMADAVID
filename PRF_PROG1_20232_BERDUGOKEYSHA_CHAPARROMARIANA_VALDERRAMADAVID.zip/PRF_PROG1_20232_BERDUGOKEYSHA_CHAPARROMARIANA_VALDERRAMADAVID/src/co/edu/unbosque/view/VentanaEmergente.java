package co.edu.unbosque.view;

import javax.swing.JOptionPane;

public class VentanaEmergente {

	public void mostrarMensaje(String mensaje) {
		JOptionPane.showMessageDialog(null, mensaje);
	}
	public void mostrarError(String mensaje) {
		JOptionPane.showMessageDialog(null, mensaje, "ERROR", JOptionPane.ERROR_MESSAGE);
	}
}
