package co.edu.unbosque.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class VentanaPrincipal extends JFrame{
	
	public JButton loteria, superastro, baloto, betplay, chance;
	private ActionListener listener;
	private JLabel fondo;
	private PanelBotones botones;
	private PanelJuegos juegos;
	
	public VentanaPrincipal(ActionListener listener) {
		this.listener = listener;
		setSize(600,500);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setBackground(new Color(176, 175, 250));
		setLayout(new BorderLayout());
		setResizable(false);
		setLocationRelativeTo(null);
		setTitle("Bienvenido");

	
        inicializar();
        setVisible(true);
	}

	public void inicializar() {

		botones = new PanelBotones(listener);
		add(botones, BorderLayout.SOUTH);
		fondo = new JLabel();
		ImageIcon fond = new ImageIcon("src/co/edu/unbosque/view/resources/Unknown forest.png");
		fondo.setIcon(new ImageIcon(fond.getImage().getScaledInstance(600, 500, Image.SCALE_DEFAULT)));
		add(fondo); 
		
		juegos = new PanelJuegos(listener);
		add(juegos, BorderLayout.NORTH);
	}


}
