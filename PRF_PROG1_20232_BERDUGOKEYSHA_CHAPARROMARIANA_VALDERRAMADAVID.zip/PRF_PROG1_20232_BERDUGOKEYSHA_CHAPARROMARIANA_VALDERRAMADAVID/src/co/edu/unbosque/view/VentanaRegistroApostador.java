package co.edu.unbosque.view;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import co.edu.unbosque.model.Apostador;

/**
 * @author Jeronimo
 *
 */
public class VentanaRegistroApostador extends JFrame {

	private JLabel etiquetaNombre, etiquetaDocumento, etiquetaEdad, etiquetaCelular, etiquetaDireccion, etiquetaSede;
	private JTextField campoNombre, campoDocumento, campoEdad, campoCelular, campoDireccion, campoSede;
	private JButton botonGuardar, botonCancelar;
	private ActionListener listener;

	public VentanaRegistroApostador(ActionListener listener) {
		this.listener = listener;
		setSize(300, 200);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setBackground(new Color(194, 225, 255));
		getContentPane().setLayout(new GridLayout(7, 2, 20, 20));
		setResizable(false);
		setLocationRelativeTo(null);
		setTitle("Registro de Apostador");

		inicializar();
		pack();

	}

	private void inicializar() {
		etiquetaNombre = new JLabel("Nombre:");
		add(etiquetaNombre);

		campoNombre = new JTextField();
		add(campoNombre);

		etiquetaEdad = new JLabel("Edad:");
		add(etiquetaEdad);

		campoEdad = new JTextField();
		add(campoEdad);

		etiquetaDocumento = new JLabel("Documento:");
		add(etiquetaDocumento);

		campoDocumento = new JTextField();
		add(campoDocumento);

		etiquetaCelular = new JLabel("Celular:");
		add(etiquetaCelular);

		campoCelular = new JTextField();
		add(campoCelular);

		etiquetaDireccion = new JLabel("Dirección:");
		add(etiquetaDireccion);

		campoDireccion = new JTextField();
		add(campoDireccion);

		etiquetaSede = new JLabel("Sede:");
		add(etiquetaSede);

		campoSede = new JTextField();
		add(campoSede);

		botonGuardar = new JButton("Guardar");
		add(botonGuardar);
		botonGuardar.setActionCommand("GuardarRegistro");
		botonGuardar.addActionListener(listener);

		botonCancelar = new JButton("Cancelar");
		botonCancelar.setActionCommand("CancelarRegistro");
		botonCancelar.addActionListener(listener);
		add(botonCancelar);
	}



	public JLabel getEtiquetaNombre() {
		return etiquetaNombre;
	}

	public void setEtiquetaNombre(JLabel etiquetaNombre) {
		this.etiquetaNombre = etiquetaNombre;
	}

	public JLabel getEtiquetaDocumento() {
		return etiquetaDocumento;
	}

	public void setEtiquetaDocumento(JLabel etiquetaDocumento) {
		this.etiquetaDocumento = etiquetaDocumento;
	}

	public JLabel getEtiquetaEdad() {
		return etiquetaEdad;
	}

	public void setEtiquetaEdad(JLabel etiquetaEdad) {
		this.etiquetaEdad = etiquetaEdad;
	}

	public JLabel getEtiquetaCelular() {
		return etiquetaCelular;
	}

	public void setEtiquetaCelular(JLabel etiquetaCelular) {
		this.etiquetaCelular = etiquetaCelular;
	}

	public JLabel getEtiquetaDireccion() {
		return etiquetaDireccion;
	}

	public void setEtiquetaDireccion(JLabel etiquetaDireccion) {
		this.etiquetaDireccion = etiquetaDireccion;
	}

	public JLabel getEtiquetaSede() {
		return etiquetaSede;
	}

	public void setEtiquetaSede(JLabel etiquetaSede) {
		this.etiquetaSede = etiquetaSede;
	}

	public JTextField getCampoNombre() {
		return campoNombre;
	}

	public void setCampoNombre(JTextField campoNombre) {
		this.campoNombre = campoNombre;
	}

	public JTextField getCampoDocumento() {
		return campoDocumento;
	}

	public void setCampoDocumento(JTextField campoDocumento) {
		this.campoDocumento = campoDocumento;
	}

	public JTextField getCampoEdad() {
		return campoEdad;
	}

	public void setCampoEdad(JTextField campoEdad) {
		this.campoEdad = campoEdad;
	}

	public JTextField getCampoCelular() {
		return campoCelular;
	}

	public void setCampoCelular(JTextField campoCelular) {
		this.campoCelular = campoCelular;
	}

	public JTextField getCampoDireccion() {
		return campoDireccion;
	}

	public void setCampoDireccion(JTextField campoDireccion) {
		this.campoDireccion = campoDireccion;
	}

	public JTextField getCampoSede() {
		return campoSede;
	}

	public void setCampoSede(JTextField campoSede) {
		this.campoSede = campoSede;
	}

	public JButton getBotonGuardar() {
		return botonGuardar;
	}

	public void setBotonGuardar(JButton botonGuardar) {
		this.botonGuardar = botonGuardar;
	}

	public JButton getBotonCancelar() {
		return botonCancelar;
	}

	public void setBotonCancelar(JButton botonCancelar) {
		this.botonCancelar = botonCancelar;
	}

	public ActionListener getListener() {
		return listener;
	}

	public void setListener(ActionListener listener) {
		this.listener = listener;
	}

}
