package co.edu.unbosque.view;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import co.edu.unbosque.controller.Controlador;

public class VentanaChance extends JFrame {

	private JLabel[] etiquetaNumeros;
	private JTextField[] campoNumeros;
	private JButton jugar, salir;
	private ActionListener listener;
	private Controlador controlador;

	public VentanaChance(ActionListener listener,Controlador controlador) {
		this.listener = listener;
		 this.controlador = controlador; 
		setSize(600, 500);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		getContentPane().setBackground(new Color(194, 225, 255));
		setLayout(new GridLayout(3, 2, 10, 10));
		setResizable(false);
		setLocationRelativeTo(null);
		setTitle("Chance");
		inicializar();
		setVisible(false);
		pack();

	}

	private void inicializar() {
		etiquetaNumeros = new JLabel[4];
		campoNumeros = new JTextField[4];

		for (int i = 0; i < 4; i++) {
			etiquetaNumeros[i] = new JLabel("Número " + (i + 1) + ":");
			getContentPane().add(etiquetaNumeros[i]);

			campoNumeros[i] = new JTextField();
			getContentPane().add(campoNumeros[i]);
		}

		jugar = new JButton("Jugar");
		jugar.setActionCommand("JugarChance");
		jugar.addActionListener(listener);
		getContentPane().add(jugar);

		salir = new JButton("Salir");
		salir.setActionCommand("SalirChance");
		salir.addActionListener(listener);
		getContentPane().add(salir);

		jugar.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int[] numeros = new int[4];
				for (int i = 0; i < 4; i++) {
					try {
						numeros[i] = Integer.parseInt(campoNumeros[i].getText());
					} catch (NumberFormatException ex) {
						JOptionPane.showMessageDialog(null, "Ingrese números válidos en todos los campos.");
						return;
					}
				}

				controlador.jugarChance(numeros);
			}
		});
	}

	public JLabel[] getEtiquetaNumeros() {
		return etiquetaNumeros;
	}

	public void setEtiquetaNumeros(JLabel[] etiquetaNumeros) {
		this.etiquetaNumeros = etiquetaNumeros;
	}

	public JTextField[] getCampoNumeros() {
		return campoNumeros;
	}

	public void setCampoNumeros(JTextField[] campoNumeros) {
		this.campoNumeros = campoNumeros;
	}

	public JButton getJugar() {
		return jugar;
	}

	public void setJugar(JButton jugar) {
		this.jugar = jugar;
	}

	public JButton getSalir() {
		return salir;
	}

	public void setSalir(JButton salir) {
		this.salir = salir;
	}

	public ActionListener getListener() {
		return listener;
	}

	public void setListener(ActionListener listener) {
		this.listener = listener;
	}

	public Controlador getControlador() {
		return controlador;
	}

	public void setControlador(Controlador controlador) {
		this.controlador = controlador;
	}
	

}
