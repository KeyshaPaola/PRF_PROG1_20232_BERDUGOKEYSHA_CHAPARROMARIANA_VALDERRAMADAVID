package co.edu.unbosque.view;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import co.edu.unbosque.controller.Controlador;

public class VentanaSuperastro extends JFrame{

	private JLabel[] etiquetasNumeros;
    private JTextField[] camposNumeros;
    private JLabel etiquetaSigno;
    private JTextField campoSigno;
    private JButton jugar, salir;
    
    private Controlador controlador;
    private JComboBox opciones;
    private ActionListener listener;
	public VentanaSuperastro(ActionListener listener) {
		this.listener = listener;
		setSize(600,500);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		getContentPane().setBackground(new Color(194, 225, 255));
		getContentPane().setLayout(new GridLayout(3, 2,20,20));
		setResizable(false);
		setLocationRelativeTo(null);
		inicializar();
		setVisible(false);
		setTitle("Superastro");
		pack();
	}

		private void inicializar() {
			
			etiquetasNumeros = new JLabel[4];
			camposNumeros = new JTextField[4];
			
			for (int i = 0; i < 4; i++) {
				etiquetasNumeros[i] = new JLabel("Numero "  +(i + 1)+ ":" );
				getContentPane().add(etiquetasNumeros[i]);
				
				camposNumeros[i] = new JTextField();
	            getContentPane().add(camposNumeros[i]);
				
			}
			
	        String[] signo = {"Aries", "Tauro", "Géminis", "Cáncer", "Leo", "Virgo", "Libra",
	    			"Escorpio", "Sagitario", "Capricornio", "Acuario", "Piscis"}; 
		    opciones = new JComboBox(signo); 
		    opciones.setSelectedIndex(0); 
		    opciones.setBackground(new Color(176, 175, 250)); 
		    etiquetaSigno = new JLabel("Signo del zodiaco:");
	        getContentPane().add(etiquetaSigno);
		    getContentPane().add(opciones); 

	        jugar = new JButton("Jugar");
	        getContentPane().add(jugar);
	        jugar.setActionCommand("JugarSuper");
	        jugar.addActionListener(listener);

	        salir = new JButton("Salir");
	        getContentPane().add(salir);
	        salir.setActionCommand("SalirSuper");
	        salir.addActionListener(listener);
	        
	        
			
		}

		public JLabel[] getEtiquetasNumeros() {
			return etiquetasNumeros;
		}

		public void setEtiquetasNumeros(JLabel[] etiquetasNumeros) {
			this.etiquetasNumeros = etiquetasNumeros;
		}

		public JTextField[] getCamposNumeros() {
			return camposNumeros;
		}

		public void setCamposNumeros(JTextField[] camposNumeros) {
			this.camposNumeros = camposNumeros;
		}

		public JLabel getEtiquetaSigno() {
			return etiquetaSigno;
		}

		public void setEtiquetaSigno(JLabel etiquetaSigno) {
			this.etiquetaSigno = etiquetaSigno;
		}

		public JTextField getCampoSigno() {
			return campoSigno;
		}

		public void setCampoSigno(JTextField campoSigno) {
			this.campoSigno = campoSigno;
		}

		public JButton getJugar() {
			return jugar;
		}

		public void setJugar(JButton jugar) {
			this.jugar = jugar;
		}

		public JButton getSalir() {
			return salir;
		}

		public void setSalir(JButton salir) {
			this.salir = salir;
		}

		public Controlador getControlador() {
			return controlador;
		}

		public void setControlador(Controlador controlador) {
			this.controlador = controlador;
		}

		public JComboBox getOpciones() {
			return opciones;
		}

		public void setOpciones(JComboBox opciones) {
			this.opciones = opciones;
		}
		
}
