package co.edu.unbosque.view;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import co.edu.unbosque.controller.Controlador;

public class VentanaBaloto extends JFrame {
	private JLabel[] etiquetasNumeros;
	private JTextField[] camposNumeros;
	private JButton jugar, salir;

	private Controlador controlador;
	private ActionListener listener;

	public VentanaBaloto(ActionListener listener) {
		this.listener = listener;
		setSize(600, 500);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		getContentPane().setBackground(new Color(194, 225, 255));
		setLayout(new GridLayout(8, 2, 20, 20));
		setResizable(false);
		setLocationRelativeTo(null);
		inicializar();
		setVisible(false);
		setTitle("Baloto");
		pack();
	}

	private void inicializar() {

		etiquetasNumeros = new JLabel[6];
		camposNumeros = new JTextField[6];

		for (int i = 0; i < 6; i++) {
			etiquetasNumeros[i] = new JLabel("Número " + (i + 1) + ":");
			getContentPane().add(etiquetasNumeros[i]);

			camposNumeros[i] = new JTextField();
			getContentPane().add(camposNumeros[i]);
		}

		jugar = new JButton("Jugar");
		getContentPane().add(jugar);
		jugar.setActionCommand("JugarBaloto");
		jugar.addActionListener(listener);

		salir = new JButton("Salir");
		getContentPane().add(salir);
		salir.setActionCommand("SalirBaloto");
		salir.addActionListener(listener);

		jugar.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				int[] numeros = new int[6];
				for (int i = 0; i < 6; i++) {

					try {
						numeros[i] = Integer.parseInt(camposNumeros[i].getText());

					} catch (NumberFormatException ex) {

						System.out.println("Ingrese numeros validos en todos los campos.");
						return;
					}
				}

				controlador.procesarBaloto(numeros);
			}
		});

	}
}
