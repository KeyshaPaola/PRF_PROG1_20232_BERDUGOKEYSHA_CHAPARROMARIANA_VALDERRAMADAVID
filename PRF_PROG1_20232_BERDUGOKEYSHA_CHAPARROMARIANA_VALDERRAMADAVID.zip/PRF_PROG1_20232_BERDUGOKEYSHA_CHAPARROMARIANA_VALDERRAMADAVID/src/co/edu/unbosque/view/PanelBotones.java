package co.edu.unbosque.view;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileOutputStream;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.text.Document;
import javax.swing.text.Element;
import javax.swing.text.ParagraphView;
public class PanelBotones extends JPanel {

	private JButton apuestas;
	private JButton total;
	private JButton clientes;
	private JButton detalles;
	private ActionListener listener;

	public PanelBotones(ActionListener listener) {
		this.listener = listener;
		this.setSize(300, 300);
		this.setBackground(new Color(176, 175, 250));
		this.setLayout(new FlowLayout(FlowLayout.CENTER));
		inicializar();
		this.setVisible(true);

	}

	private void inicializar() {

		clientes = new JButton("Clientes");
		clientes.setVisible(true);
		clientes.setBackground(new Color(165, 207, 246));
		add(clientes);

		apuestas = new JButton("Valor Apuestas");
		apuestas.setVisible(true);
		apuestas.setBackground(new Color(165, 207, 246));
		add(apuestas);

		detalles = new JButton("Detalle Apuestas");
		detalles.setVisible(true);
		detalles.setBackground(new Color(165, 207, 246));
	    detalles.addActionListener(new DetallesActionListener());
		add(detalles);

		total = new JButton("Total Apuestas");
		total.setVisible(true);
		total.setBackground(new Color(165, 207, 246));
		total.addActionListener(new TotalActionListener());
		add(total);
	}
	 private class DetallesActionListener implements ActionListener {
	        @Override
	        public void actionPerformed(ActionEvent e) {
	            listener.actionPerformed(new ActionEvent(this, ActionEvent.ACTION_PERFORMED, "Detalles"));
	        }
	    }

	 private class TotalActionListener implements ActionListener {
	        @Override
	        public void actionPerformed(ActionEvent e) {
	            listener.actionPerformed(new ActionEvent(this, ActionEvent.ACTION_PERFORMED, "Total"));
	        }
	    }
	
	 private void generarInformePDF(String nombreArchivo, Element contenido) {
	        try {
	           // Document documento = new Document();
	           // PdfWriter.getInstance(document, new FileOutputStream(nombreArchivo));
	           // documento.open();
	          //  documento.add(new ParagraphView(contenido));
	           // documento.close();
	            JOptionPane.showMessageDialog(null, "Informe generado correctamente en " + nombreArchivo);
	        } catch (Exception ex) {
	            ex.printStackTrace();
	            JOptionPane.showMessageDialog(null, "Error al generar el informe en PDF");
	        }
	    }

	public JButton getApuestas() {
		return apuestas;
	}

	public void setApuestas(JButton apuestas) {
		this.apuestas = apuestas;
	}

	public JButton getTotal() {
		return total;
	}

	public void setTotal(JButton total) {
		this.total = total;
	}

	public JButton getClientes() {
		return clientes;
	}

	public void setClientes(JButton clientes) {
		this.clientes = clientes;
	}

	public JButton getDetalles() {
		return detalles;
	}

	public void setDetalles(JButton detalles) {
		this.detalles = detalles;
	}

	public ActionListener getListener() {
		return listener;
	}

	public void setListener(ActionListener listener) {
		this.listener = listener;
	}

}
