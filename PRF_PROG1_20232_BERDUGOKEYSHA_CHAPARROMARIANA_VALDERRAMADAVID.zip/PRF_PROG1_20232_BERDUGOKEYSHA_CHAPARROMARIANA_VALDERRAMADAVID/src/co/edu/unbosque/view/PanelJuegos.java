package co.edu.unbosque.view;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;

public class PanelJuegos extends JPanel {
	
	public JButton loteria, superastro, baloto, betplay, chance,registrar;
	private ActionListener listener;

	public PanelJuegos(ActionListener listener) {
		this.listener = listener;
		this.setSize(300, 300);
		this.setBackground(new Color(176, 175, 250));
		this.setLayout(new FlowLayout(FlowLayout.CENTER));
		inicializar();
		this.setVisible(true);

	}

	public void inicializar() {
		loteria = new JButton("Loteria");
		loteria.addActionListener(listener);
		loteria.setBackground(new Color(165, 207, 246));
		add(loteria);

		superastro = new JButton("Superastro");
		superastro.addActionListener(listener);
		superastro.setBackground(new Color(165, 207, 246));
		add(superastro);

		baloto = new JButton("Baloto");
		baloto.addActionListener(listener);
		baloto.setBackground(new Color(165, 207, 246));
		add(baloto);

		betplay = new JButton("Betplay");
		betplay.addActionListener(listener);
		betplay.setBackground(new Color(165, 207, 246));
		add(betplay);

		chance = new JButton("Chance");
		chance.addActionListener(listener);
		chance.setBackground(new Color(165, 207, 246));
		add(chance);
		
		registrar = new JButton("Registrar");
		registrar.addActionListener(listener);
		registrar.setBackground(new Color(165, 207, 246));
		add(registrar);
	}
}
