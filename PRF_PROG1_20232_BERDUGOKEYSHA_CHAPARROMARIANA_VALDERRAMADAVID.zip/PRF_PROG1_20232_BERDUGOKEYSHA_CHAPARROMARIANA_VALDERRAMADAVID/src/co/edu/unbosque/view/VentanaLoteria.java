package co.edu.unbosque.view;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class VentanaLoteria extends JFrame{

	private JLabel numero;
	private JLabel serie;
	private JTextField numeroField;
	private JTextField serieField;
	private JButton jugar,salir;
	private JComboBox opciones;

	private ActionListener listener;

	public VentanaLoteria(ActionListener listener) {
		this.listener = listener;
		setSize(600, 500);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		getContentPane().setBackground(new Color(194, 225, 255));
		getContentPane().setLayout(new GridLayout(2, 3,20,20));
		setResizable(false);
		setLocationRelativeTo(null);
		setTitle("Bienvenido");
		inicializar();
		setVisible(false);
		pack();

	}

	private void inicializar() {
		numero = new JLabel("Número:");
		getContentPane().add(numero);
		

		numeroField = new JTextField();
		getContentPane().add(numeroField);

		serie = new JLabel("Serie:");
		getContentPane().add(serie);
		
		
		serieField = new JTextField();
		getContentPane().add(serieField);
		
		String[] tiposLoteria = {"Cundinamarca", "Boyacá", "Cauca"}; 
	    opciones = new JComboBox(tiposLoteria); 
	    opciones.setSelectedIndex(0); 
	    opciones.setBackground(new Color(176, 175, 250)); 
	    JLabel tipoLoteria = new JLabel("Loterías:");
	    tipoLoteria.setBounds(10, 120, 150, 30); 
	    getContentPane().add(tipoLoteria); 
	    getContentPane().add(opciones); 


		jugar = new JButton("Jugar");
		getContentPane().add(jugar);
		jugar.addActionListener(listener);
		
		salir = new JButton("Salir");
		getContentPane().add(salir);
		salir.addActionListener(listener);


	}

	public JLabel getNumero() {
		return numero;
	}

	public void setNumero(JLabel numero) {
		this.numero = numero;
	}

	public JLabel getSerie() {
		return serie;
	}

	public void setSerie(JLabel serie) {
		this.serie = serie;
	}

	public JTextField getNumeroField() {
		return numeroField;
	}

	public void setNumeroField(JTextField numeroField) {
		this.numeroField = numeroField;
	}

	public JTextField getSerieField() {
		return serieField;
	}

	public void setSerieField(JTextField serieField) {
		this.serieField = serieField;
	}

	public JButton getJugar() {
		return jugar;
	}

	public void setJugar(JButton jugar) {
		this.jugar = jugar;
	}

	public JButton getSalir() {
		return salir;
	}

	public void setSalir(JButton salir) {
		this.salir = salir;
	}

	public JComboBox getOpciones() {
		return opciones;
	}

	public void setOpciones(JComboBox opciones) {
		this.opciones = opciones;
	}

	public ActionListener getListener() {
		return listener;
	}

	public void setListener(ActionListener listener) {
		this.listener = listener;
	}
	
}
